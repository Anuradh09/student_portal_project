package com.example.student_portal_diu_flutter

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
